package shared.turboeditor.explorer

import androidx.lifecycle.ViewModel

class SelectFileViewModel : ViewModel() {

}